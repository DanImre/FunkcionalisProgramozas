#ifndef BEAD
#define BEAD

char **revall(char **, int);
char **beolvas(char *, int, int *);

#endif